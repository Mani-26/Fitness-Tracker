import React from 'react';

const Footer = () => (
  <footer>
    <p>&copy; 2025 Fitness Tracker. All rights reserved.</p>
  </footer>
);

export default Footer;
